// Inicializa Firebase
var firebaseConfig = {
  apiKey: "AIzaSyBy_VOJ0SlCY7-FbYAiOe7jplHuKlHRs5A",
  authDomain: "PROJECT_ID.firebaseapp.com",
  databaseURL: "https://PROJECT_ID.firebaseio.com",
  projectId: "appfluttermobile",
  storageBucket: "PROJECT_ID.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};
firebase.initializeApp(firebaseConfig);
